library(wordcloud)
library(tidyverse)
setwd("Z:/PROJECTS/R STUDIO PROJECT")
raw<-read.csv("RAW DATA SET/global-data-on-sustainable-energy.csv",header=T)
year<-2000:2020

#density
density_processed<-raw%>%
  select(Entity,Density.n.P.Km2.)
density_processed<-unique(density_processed)
density_processed$Density.n.P.Km2.<-as.numeric(density_processed$Density.n.P.Km2.)
density_processed<-density_processed%>%
  na.omit()

#mean density
mean(density_processed$Density.n.P.Km2.)
#median
median(density_processed$Density.n.P.Km2.)
#mode
mode<-table(density_processed$Density.n.P.Km2.)
noquote(names(mode[(mode==max(mode))]))
#standard deviation
sd(density_processed$Density.n.P.Km2.)
#variance
var(density_processed$Density.n.P.Km2.)

#pie-chart demonstrating countries in different region
pie_chart <- ggplot(density_processed, aes(x = "", y = Density.n.P.Km2., fill = Entity)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Density population in different country")
ggsave("LAND AREA AND DENSITY POPULATION/density_pie_chart.png", plot = pie_chart, width = 20, height = 20)

#land area
land_area_processed<-raw%>%
  select(Entity,Land.Area.Km2.)
land_area_processed<-unique(land_area_processed)
land_area_processed$Land.Area.Km2.<-as.numeric(land_area_processed$Land.Area.Km2.)
land_area_processed<-land_area_processed%>%
  na.omit()

#mean density
mean(land_area_processed$Land.Area.Km2.)
#median
median(land_area_processed$Land.Area.Km2.)
#mode
mode<-table(land_area_processed$Land.Area.Km2.)
noquote(names(mode[(mode==max(mode))]))           #no use
#standard deviation
sd(land_area_processed$Land.Area.Km2.)
#variance
var(land_area_processed$Land.Area.Km2.)

#pie-chart demonstrating countries in different region
pie_chart <- ggplot(land_area_processed, aes(x = "", y = Land.Area.Km2., fill = Entity)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Land Area in different country")
ggsave("LAND AREA AND DENSITY POPULATION/land_area_pie_chart.png", plot = pie_chart, width = 20, height = 20)

color_palette <- colorRampPalette(c("lightblue", "blue"))(max(land_area_processed$Land.Area.Km2.))
png("LAND AREA AND DENSITY POPULATION/land_area_word_chart.png", width = 500, height = 300)
wordcloud(words = land_area_processed$Entity, freq = land_area_processed$Land.Area.Km2., scale=c(3, 0.5),colors = color_palette)



processed <- merge(land_area_processed,density_processed, by = "Entity")
colnames(processed) <- c("Country","Land Area","Density")

# Calculate Pearson correlation coefficient
correlation <- cor(processed$`Density`,processed$`Land Area`)
correlation
#very weak or no correlation between density and land area
