library(tidyverse)
setwd("Z:/PROJECTS/R STUDIO PROJECT")
sustainable<-read.csv("RAW DATA SET/global-data-on-sustainable-energy.csv",header=T)

year<-2000:2020
sustainable_processed<-sustainable%>%
  select(Entity,Year,gdp_per_capita)

sustainable_year<-unique(sustainable$Year)         
sustainable_country<-unique(sustainable$Entity)

sustainable_matrix<-matrix(NA,length(sustainable_country),length(sustainable_year))

for(i in 1:nrow(sustainable_processed)){
  sustainable_matrix[which(sustainable_country==sustainable_processed$Entity[i]),which(sustainable_year==sustainable_processed$Year[i])]<-sustainable$gdp_per_capita[i]
}

tryCatch(
  expr={
    for(i in 1:nrow(sustainable_matrix)){
      if(sum(is.na(sustainable_matrix[i,]))==ncol(sustainable_matrix)){
        sustainable_matrix<-sustainable_matrix[-i,]
        sustainable_country<-sustainable_country[-i]
      }
    }
  },
  error = function(e){          
    message("Done")
  }
)

for(i in 1:nrow(sustainable_matrix)){
  x<-NA
  if(sum(is.na(sustainable_matrix[i,]))>0){
    for(j in 1:ncol(sustainable_matrix)){
      if(is.na(sustainable_matrix[i,j])==0){
        x<-sustainable_matrix[i,j]
      }
      else{
        if(is.na(x)){
          k<-j
          while(is.na(sustainable_matrix[i,k]) && k<ncol(sustainable_matrix)){
            k<-k+1
          }
          x<-sustainable_matrix[i,k]
          sustainable_matrix[i,j]<-x
        }
        else{
          sustainable_matrix[i,j]<-x
        }
      }
    }
  }
}
sustainable_processed<-cbind.data.frame(sustainable_country,sustainable_matrix)
sustainable_processed<-sustainable_processed%>%
  na.omit()
rownames(sustainable_processed)<-1:nrow(sustainable_processed)
colnames(sustainable_processed)<-c("Country",sustainable_year)


###################################################################################################

# Calculate growth rates for each country
overall_growth_rate<-c()
for(i in 1:nrow(sustainable_processed)){
  data<-sustainable_processed[i,2:ncol(sustainable_processed)]
  growth_rates <- data[-1] / data[-length(data)] - 1
  growth_rates <- growth_rates[growth_rates>0]
  overall_growth_rate <- c(overall_growth_rate,(exp(mean(log(1 + growth_rates))) - 1))
}
#top 5 countries with highest growth rate
descending_order_growth_rate <- order(-overall_growth_rate)  
descending_order_growth_rate<-descending_order_growth_rate[is.finite(overall_growth_rate[descending_order_growth_rate])]
descending_order_growth_rate<-descending_order_growth_rate[1:5]
top_growth_rate<-cbind.data.frame(sustainable_processed$Country[descending_order_growth_rate],overall_growth_rate[descending_order_growth_rate])

colnames(top_growth_rate)<-c("Country","Growth rate")

#bar plot
p<-ggplot(top_growth_rate, aes(x = Country, y = `Growth rate`,fill=`Growth rate`)) +
  geom_col() +
  ylab("Growth rate") +
  xlab("Country") +
  labs(title = "Country-wise top 5 growth rate") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=10)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank()) +
  theme(plot.background = element_rect(fill="#282424"))
ggsave("GDP PER CAPITA/top_5_growth_rate.png", plot = p, width = 10, height = 4,dpi=2000)

#bottom 5 countries with highest growth rate
ascending_order_growth_rate <- order(overall_growth_rate)  
ascending_order_growth_rate<-ascending_order_growth_rate[is.finite(overall_growth_rate[ascending_order_growth_rate])]
ascending_order_growth_rate<-ascending_order_growth_rate[1:5]
bottom_growth_rate<-cbind.data.frame(sustainable_processed$Country[ascending_order_growth_rate],overall_growth_rate[ascending_order_growth_rate])
colnames(bottom_growth_rate)<-c("Country","Growth rate")

#bar plot
p<-ggplot(bottom_growth_rate, aes(x = Country, y = `Growth rate`,fill=`Growth rate`)) +
  geom_col() +
  ylab("Growth rate") +
  xlab("Country") +
  labs(title = "Country-wise bottom 5 growth rate") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=10)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank())+
  theme(plot.background = element_rect(fill="#282424"))
ggsave("GDP PER CAPITA/bottom_5_growth_rate.png", plot = p, width = 10, height = 4,dpi=2000)

#####################################################################################################################


#regression and prediction
learning_dataset<-cbind.data.frame("Year"=year,t(sustainable_processed[2:ncol(sustainable_processed)]))
prediction_2021<-c()
for(i in 1:length(sustainable_processed$Country)){
  model<-lm(learning_dataset[,i+1]~Year,data=learning_dataset)
  ds<-data.frame(Year=c(2021))
  prediction_2021<-c(prediction_2021,predict(model,ds))
}
prediction_2021<-cbind.data.frame("Country"=sustainable_processed$Country,"Prediction"=prediction_2021)

prediction_2021 <- subset(prediction_2021, Prediction >= 0)  # due to regression prediction (value is negative)

#bar plot of regression in different countries 2021
p<-ggplot(prediction_2021, aes(x = Country, y = Prediction,fill=Prediction)) +
  geom_col() +
  ylab("GDP PER CAPITA") +
  xlab("Countries") +
  labs(title = "GDP PER CAPITA 2021") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=2)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank()) +
  scale_fill_gradient(low = "lightblue", high = "blue") +
  theme(plot.background = element_rect(fill="#282424"))
ggsave("GDP PER CAPITA/regression.png", plot = p, width = 10, height = 4,dpi=2000)

