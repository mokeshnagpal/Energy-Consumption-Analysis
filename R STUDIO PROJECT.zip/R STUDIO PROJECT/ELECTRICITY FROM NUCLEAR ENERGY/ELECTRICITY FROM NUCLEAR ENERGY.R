library(tidyverse)
setwd("Z:/PROJECTS/R STUDIO PROJECT")
sustainable<-read.csv("RAW DATA SET/global-data-on-sustainable-energy.csv",header=T)

year<-2000:2020
sustainable_processed<-sustainable%>%
  select(Entity,Year,Electricity.from.nuclear..TWh.)

sustainable_year<-unique(sustainable$Year)         
sustainable_country<-unique(sustainable$Entity)

sustainable_matrix<-matrix(NA,length(sustainable_country),length(sustainable_year))

for(i in 1:nrow(sustainable_processed)){
  sustainable_matrix[which(sustainable_country==sustainable_processed$Entity[i]),which(sustainable_year==sustainable_processed$Year[i])]<-sustainable$Electricity.from.nuclear..TWh.[i]
}

tryCatch(
  expr={
    for(i in 1:nrow(sustainable_matrix)){
      if(sum(is.na(sustainable_matrix[i,]))==ncol(sustainable_matrix)){
        sustainable_matrix<-sustainable_matrix[-i,]
        sustainable_country<-sustainable_country[-i]
      }
    }
  },
  error = function(e){          
    message("Done")
  }
)

for(i in 1:nrow(sustainable_matrix)){
  x<-NA
  if(sum(is.na(sustainable_matrix[i,]))>0){
    for(j in 1:ncol(sustainable_matrix)){
      if(is.na(sustainable_matrix[i,j])==0){
        x<-sustainable_matrix[i,j]
      }
      else{
        if(is.na(x)){
          k<-j
          while(is.na(sustainable_matrix[i,k]) && k<ncol(sustainable_matrix)){
            k<-k+1
          }
          x<-sustainable_matrix[i,k]
          sustainable_matrix[i,j]<-x
        }
        else{
          sustainable_matrix[i,j]<-x
        }
      }
    }
  }
}
sustainable_processed<-cbind.data.frame(sustainable_country,sustainable_matrix)
sustainable_processed<-sustainable_processed%>%
  na.omit()
rownames(sustainable_processed)<-1:nrow(sustainable_processed)
colnames(sustainable_processed)<-c("Country",sustainable_year)


###################################################################################################


# Calculate Electricity from nuclear energy for each country
overall_electricity_from_nuclear_energy<-cbind.data.frame("Country" = sustainable_processed$Country ,"Electricity from nuclear energy" = sustainable_processed$`2020`)

#sorting
overall_electricity_from_nuclear_energy <- overall_electricity_from_nuclear_energy[order(overall_electricity_from_nuclear_energy$`Electricity from nuclear energy`),]

#top 10 countries with highest Electricity from nuclear energy
top_electricity_from_nuclear_energy_without_land_area<-tail(overall_electricity_from_nuclear_energy,10)

#bar plot
p<-ggplot(top_electricity_from_nuclear_energy_without_land_area, aes(x = Country, y = `Electricity from nuclear energy`,fill=`Electricity from nuclear energy`)) +
  geom_col() +
  ylab("Electricity from nuclear energy") +
  xlab("Country") +
  labs(caption ="2000-2020(Last two Decade)", title = "Country-wise top 10 Electricity from nuclear energy") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=10)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(plot.background = element_rect(fill = "#282424")) +
  theme(plot.caption = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank())
ggsave("ELECTRICITY FROM NUCLEAR ENERGY/top_10_electricity_from_nuclear_energy.png", plot = p, width = 10, height = 4,dpi=2000)


#bottom 10 countries with highest Electricity from nuclear energy
bottom_electricity_from_nuclear_energy_without_land_area<-head(overall_electricity_from_nuclear_energy,10)

#bar plot
p<-ggplot(bottom_electricity_from_nuclear_energy_without_land_area, aes(x = Country, y = `Electricity from nuclear energy`,fill=`Electricity from nuclear energy`)) +
  geom_col() +
  ylab("Electricity Availablity") +
  xlab("Country") +
  labs(caption ="2000-2020(Last two Decade)", title = "Country-wise bottom 10 Electricity from nuclear energy") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=10)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(plot.caption = element_text(color = "white")) +
  theme(plot.background = element_rect(fill = "#282424")) +
  theme(panel.grid.major.x = element_blank())
ggsave("ELECTRICITY FROM NUCLEAR ENERGY/bottom_10_electricity_from_nuclear_energy.png", plot = p, width = 10, height = 4,dpi=2000)


###################################################################################################

# Calculate growth rates for each country
overall_growth_rate<-c()
for(i in 1:nrow(sustainable_processed)){
  data<-sustainable_processed[i,2:ncol(sustainable_processed)]
  growth_rates <- data[-1] / data[-length(data)] - 1
  growth_rates <- growth_rates[growth_rates>0]
  overall_growth_rate <- c(overall_growth_rate,(exp(mean(log(1 + growth_rates))) - 1))
}
#top 5 countries with highest growth rate
descending_order_growth_rate <- order(-overall_growth_rate)  
descending_order_growth_rate<-descending_order_growth_rate[is.finite(overall_growth_rate[descending_order_growth_rate])]
descending_order_growth_rate<-descending_order_growth_rate[1:5]
top_growth_rate<-cbind.data.frame(sustainable_processed$Country[descending_order_growth_rate],overall_growth_rate[descending_order_growth_rate])

colnames(top_growth_rate)<-c("Country","Growth rate")

#bar plot
p<-ggplot(top_growth_rate, aes(x = Country, y = `Growth rate`,fill=`Growth rate`)) +
  geom_col() +
  ylab("Growth rate") +
  xlab("Country") +
  labs(title = "Country-wise top 5 growth rate") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=10)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank()) +
  theme(plot.background = element_rect(fill="#282424"))
ggsave("ELECTRICITY FROM NUCLEAR ENERGY/top_5_growth_rate.png", plot = p, width = 10, height = 4,dpi=2000)

#bottom 5 countries with highest growth rate
ascending_order_growth_rate <- order(overall_growth_rate)  
ascending_order_growth_rate<-ascending_order_growth_rate[is.finite(overall_growth_rate[ascending_order_growth_rate])]
ascending_order_growth_rate<-ascending_order_growth_rate[1:5]
bottom_growth_rate<-cbind.data.frame(sustainable_processed$Country[ascending_order_growth_rate],overall_growth_rate[ascending_order_growth_rate])
colnames(bottom_growth_rate)<-c("Country","Growth rate")

#bar plot
p<-ggplot(bottom_growth_rate, aes(x = Country, y = `Growth rate`,fill=`Growth rate`)) +
  geom_col() +
  ylab("Growth rate") +
  xlab("Country") +
  labs(title = "Country-wise bottom 5 growth rate") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=10)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank())+
  theme(plot.background = element_rect(fill="#282424"))
ggsave("ELECTRICITY FROM NUCLEAR ENERGY/bottom_5_growth_rate.png", plot = p, width = 10, height = 4,dpi=2000)

#####################################################################################################################


#regression and prediction
learning_dataset<-cbind.data.frame("Year"=year,t(sustainable_processed[2:ncol(sustainable_processed)]))
prediction_2021<-c()
for(i in 1:length(sustainable_processed$Country)){
  model<-lm(learning_dataset[,i+1]~Year,data=learning_dataset)
  ds<-data.frame(Year=c(2021))
  prediction_2021<-c(prediction_2021,predict(model,ds))
}
prediction_2021<-cbind.data.frame("Country"=sustainable_processed$Country,"Prediction"=prediction_2021)

prediction_2021 <- subset(prediction_2021, Prediction >= 0)  # due to regression prediction (value is negative)

#bar plot of regression in different countries 2021
p<-ggplot(prediction_2021, aes(x = Country, y = Prediction,fill=Prediction)) +
  geom_col() +
  ylab("ELECTRICITY FROM NUCLEAR ENERGY") +
  xlab("Countries") +
  labs(title = "ELECTRICITY FROM NUCLEAR ENERGY 2021") +
  theme_minimal() +
  theme(axis.text.x = element_text(size=2)) +
  theme(axis.text.x = element_text(angle=90)) +
  theme(legend.text = element_text(color = "white")) +
  theme(legend.title = element_text(color = "white")) +
  theme(axis.text.x = element_text(color = "white")) +
  theme(axis.text.y = element_text(color = "white")) +
  theme(axis.title.x = element_text(color = "white")) +
  theme(axis.title.y = element_text(color = "white")) +
  theme(plot.title = element_text(color = "white")) +
  theme(panel.grid.major.x = element_blank()) +
  scale_fill_gradient(low = "white", high = "darkgrey") +
  theme(plot.background = element_rect(fill="#282424"))
ggsave("ELECTRICITY FROM NUCLEAR ENERGY/regression.png", plot = p, width = 10, height = 4,dpi=2000)

